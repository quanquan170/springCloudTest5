create
  definer = edu@`%` procedure sp_name(IN id int)
begin
SELECT id;
set id = 2;
SELECT id;
end;

